train = read.csv("5dc975b0250f1_Training_Dataset.csv")
test = read.csv("5dc97593aef65_Testing_Dataset_final.csv")

summary(train)

train$weight_class = as.character(train$weight_class)

 
train$no_of_rounds =  grepl("Women", train$weight_class)

colnames(train)[colnames(train) == "no_of_rounds"] = "Sex"
train$Sex[train$Sex] = "Female"
train$Sex[train$Sex != "Female" ] = "Male"


colnames(train)[1] = colnames(test)[1] 

test$Winner = NA

full = rbind(train, test)
full$date = as.Date(full$date , "%d-%m-%Y")


full$b_avg_body_pct =  full$B_avg_BODY_landed*100/(full$B_avg_BODY_att+0.1)
full$b_avg_clinch_pct = full$B_avg_CLINCH_landed*100/(full$B_avg_CLINCH_att+0.1)
full$b_avg_dis_pct = full$B_avg_DISTANCE_landed*100/(0.1+full$B_avg_DISTANCE_att)
full$b_avg_ground_pct = full$B_avg_GROUND_landed*100/(0.1+ full$B_avg_GROUND_att)
full$b_avg_head_pct = full$B_avg_HEAD_landed*100/(0.1 + full$B_avg_HEAD_att)
full$b_avg_leg_pct = full$B_avg_LEG_landed*100/(0.1 + full$B_avg_LEG_att)
full$b_avg_totalstrik_pct = full$B_avg_TOTAL_STR_landed *100/(0.1+full$B_avg_TOTAL_STR_att)

full$b_avg_opp_body_pct = full$B_avg_opp_BODY_landed*100/(0.1+ full$B_avg_opp_BODY_att)
full$b_avg_opp_clinch_pct = full$B_avg_opp_CLINCH_landed*100/(0.1+full$B_avg_opp_CLINCH_att )
full$b_avg_opp_dis_pct = full$B_avg_opp_DISTANCE_landed*100/(0.1+full$B_avg_opp_DISTANCE_att)
full$b_avg_opp_ground_pct = full$B_avg_opp_GROUND_landed*100/(0.1+full$B_avg_opp_GROUND_att)
full$b_avg_opp_head_pct = full$B_avg_opp_HEAD_landed*100/(0.1+ full$B_avg_opp_HEAD_att)
full$b_avg_opp_leg_pct = full$B_avg_opp_LEG_landed*100/(0.1+full$B_avg_opp_LEG_att)
full$b_avg_opp_totalstrik_pct = full$B_avg_opp_TOTAL_STR_landed *100/(0.1+full$B_avg_opp_TOTAL_STR_att )


full$r_avg_body_pct =  full$R_avg_BODY_landed*100/(full$R_avg_BODY_att+0.1)
full$r_avg_clinch_pct = full$R_avg_CLINCH_landed*100/(full$R_avg_CLINCH_att+0.1)
full$r_avg_dis_pct = full$R_avg_DISTANCE_landed*100/(0.1+full$R_avg_DISTANCE_att)
full$r_avg_ground_pct = full$R_avg_GROUND_landed*100/(0.1+ full$R_avg_GROUND_att)
full$r_avg_head_pct = full$R_avg_HEAD_landed*100/(0.1 + full$R_avg_HEAD_att)
full$r_avg_leg_pct = full$R_avg_LEG_landed*100/(0.1 + full$R_avg_LEG_att)
full$r_avg_totalstrik_pct = full$R_avg_TOTAL_STR_landed *100/(0.1+full$R_avg_TOTAL_STR_att)

full$r_avg_opp_body_pct = full$R_avg_opp_BODY_landed*100/(0.1+ full$R_avg_opp_BODY_att)
full$r_avg_opp_clinch_pct = full$R_avg_opp_CLINCH_landed*100/(0.1+full$R_avg_opp_CLINCH_att )
full$r_avg_opp_dis_pct = full$R_avg_opp_DISTANCE_landed*100/(0.1+full$R_avg_opp_DISTANCE_att)
full$r_avg_opp_ground_pct = full$R_avg_opp_GROUND_landed*100/(0.1+full$R_avg_opp_GROUND_att)
full$r_avg_opp_head_pct = full$R_avg_opp_HEAD_landed*100/(0.1+ full$R_avg_opp_HEAD_att)
full$r_avg_opp_leg_pct = full$R_avg_opp_LEG_landed*100/(0.1+full$R_avg_opp_LEG_att)
full$r_avg_opp_totalstrik_pct = full$R_avg_opp_TOTAL_STR_landed *100/(0.1+full$R_avg_opp_TOTAL_STR_att )








full = full[,-c(4,6,8,9,12,13,14,15:22,24,25,28,29,32,33,35,36,39:48,50,51,54,55,58,59,61,62,66:71,74,76,79,80:89,91,92,95,96,99,100,102,103,106:115,117,118,121,122,125,126,128,129,133:138,141,143)]

full$b_streak = full$B_current_win_streak - full$B_current_lose_streak
full$r_streak = full$R_current_win_streak - full$R_current_lose_streak
full = full[,-c(6,7,28,29)]

#ATTACKING SCORES
full$b_attack1 = (full$B_avg_KD - mean(full$B_avg_KD))/max(full$B_avg_KD) +
                  (full$B_avg_PASS- mean(full$B_avg_PASS))/max(full$B_avg_PASS) +
                 (full$B_avg_REV - mean(full$B_avg_REV))/max(full$B_avg_REV) +
                (full$B_avg_SUB_ATT- mean(full$B_avg_SUB_ATT))/max(full$B_avg_SUB_ATT)- ((full$R_avg_KD - mean(full$R_avg_KD))/max(full$R_avg_KD) +
                      (full$R_avg_PASS- mean(full$R_avg_PASS))/max(full$R_avg_PASS) +
                      (full$R_avg_REV - mean(full$R_avg_REV))/max(full$R_avg_REV) +
                      (full$R_avg_SUB_ATT- mean(full$R_avg_SUB_ATT))/max(full$R_avg_SUB_ATT)) 

full$b_attack2 =  full$b_avg_body_pct + full$b_avg_clinch_pct + full$b_avg_dis_pct +
  full$b_avg_ground_pct+full$b_avg_head_pct + full$b_avg_leg_pct+
  full$b_avg_totalstrik_pct + full$B_avg_SIG_STR_pct*100 + full$B_avg_TD_pct*100 - 
  full$r_avg_body_pct - full$r_avg_clinch_pct - full$r_avg_dis_pct - 
  full$r_avg_ground_pct - full$r_avg_head_pct - full$r_avg_leg_pct- 
  full$r_avg_totalstrik_pct - full$R_avg_SIG_STR_pct*100 - full$R_avg_TD_pct*100

#### DEFENDING SCORES
full$b_def_1 = (full$B_avg_opp_KD- mean(full$B_avg_opp_KD))/max(full$B_avg_opp_KD) + 
  (full$B_avg_opp_PASS - mean(full$B_avg_opp_PASS))/max(full$B_avg_opp_PASS) +
   (full$B_avg_opp_SUB_ATT-mean(full$B_avg_opp_SUB_ATT))/max(full$B_avg_opp_SUB_ATT)+
  (full$B_avg_opp_REV - mean(full$B_avg_opp_REV))/max(full$B_avg_opp_PASS) -
  (  (full$R_avg_opp_SUB_ATT-mean(full$R_avg_opp_SUB_ATT))/max(full$R_avg_opp_SUB_ATT)+
       (full$R_avg_opp_KD - mean(full$R_avg_opp_KD))/max(full$R_avg_opp_KD) + 
      (full$R_avg_opp_PASS-mean(full$R_avg_opp_PASS))/max(full$R_avg_opp_PASS)+ (full$R_avg_opp_REV - mean(full$R_avg_opp_REV))/max(full$R_avg_opp_REV))
full$b_def_2 = full$B_avg_opp_SIG_STR_pct*100  + full$B_avg_opp_TD_pct*100 +
full$b_avg_opp_body_pct+full$b_avg_opp_clinch_pct +
  full$b_avg_opp_dis_pct + full$b_avg_opp_totalstrik_pct + full$b_avg_opp_ground_pct+ 
  full$b_avg_opp_head_pct + full$b_avg_opp_leg_pct-(
    full$R_avg_opp_SIG_STR_pct*100   + full$R_avg_opp_TD_pct*100 +
    full$r_avg_opp_body_pct+full$r_avg_opp_clinch_pct + full$r_avg_opp_dis_pct+
      full$r_avg_opp_totalstrik_pct + full$r_avg_opp_ground_pct+ full$r_avg_opp_head_pct+
      full$r_avg_opp_leg_pct)


full1 = full[,c(1,2,3,4,12,13,20,21,22,23,24,25,32,33,40,41,42,43,44,45,46,47,48,77:82)]



full1$bwinloss = full1$B_wins/(full1$B_wins+full1$B_losses)
full1$rwinloss = full1$R_wins/(full1$R_wins+ full1$R_losses)


full2 = full1[,c(5,8,9,13,16,17,21,22,23,24:31)]


full3 = full2[,c(1:8,10:17,9)]
full3$agediff = full3$B_age-full3$R_age
full3$timediff = full3$B_total_time_fought.seconds.-full3$R_total_time_fought.seconds.
full3 = full3[,-c(2,5)]

full3$b_def_2 = full3$b_def_2/100
full3$b_attack2 = full3$b_attack2/100
full3$longeststreakdiff = full3$B_longest_win_streak-full3$R_longest_win_streak
full3$titlediff = full3$B_total_title_bouts - full3$R_total_title_bouts
full3$streakdiff = full3$b_streak - full3$r_streak
full3$winlossdiff = full3$bwinloss - full3$rwinloss
full3$totdef = (full3$b_def_1 - mean(full3$b_def_1))/max(full3$b_def_1) + (full3$b_def_2 - mean(full3$b_def_2))/max(full3$b_def_2) 
full3$totatt = (full3$b_attack1 - mean(full3$b_attack1))/max(full3$b_attack1) + (full3$b_attack2 - mean(full3$b_attack2))/max(full3$b_attack2) 

test = full3[is.na(full3$Winner), ]

full3 = full3[!full3$Winner== "Draw",     ]
train = full3[!is.na(full3$Winner), ]


summary(train)
train$Winner = as.character(train$Winner)
train$Winner = as.factor(train$Winner)

colnames(train)


library(h2o)

h2o.init()

trainx = train[,colnames(train)[-c(1,2,3,4,7,8)]]
trainx = trainx[,c(1:8,10:17,9)]
train1 = as.h2o(trainx)
y <- "Winner"
x <- colnames(trainx)[-17]
rf4 = h2o.randomForest( x=x , y = "Winner" , 
                       training_frame = train1, nfolds = 5,
                       keep_cross_validation_models = F,
                       keep_cross_validation_predictions = FALSE,
                       keep_cross_validation_fold_assignment = FALSE,
                       score_each_iteration = FALSE, score_tree_interval = 0,
                       fold_assignment = "Stratified",
                       fold_column = NULL,
                       ignore_const_cols = TRUE,
                       offset_column = NULL,
                       weights_column = NULL, balance_classes = FALSE,
                       class_sampling_factors = NULL, max_after_balance_size = 5,
                       max_hit_ratio_k = 0, ntrees = 55, max_depth = 5, min_rows = 20,
                       nbins = 20, nbins_top_level = 1024, nbins_cats = 1024,
                       r2_stopping = Inf, stopping_rounds = 20, stopping_metric = "logloss", stopping_tolerance = 0.001,
                       max_runtime_secs = 0, seed = -7820439226169717876,
                       build_tree_one_node = FALSE,
                       mtries = -1, sample_rate = 0.63, sample_rate_per_class = NULL,
                       binomial_double_trees = FALSE, checkpoint = NULL,
                       col_sample_rate_change_per_level = 1, col_sample_rate_per_tree = 1,
                       min_split_improvement = 1e-05, histogram_type = "AUTO",
                       categorical_encoding = "AUTO", 
                       calibrate_model = FALSE, calibration_frame = NULL,
                       distribution =  "bernoulli",
                       custom_metric_func = NULL, export_checkpoints_dir = NULL,
                       check_constant_response = TRUE, verbose = T) 


rf4
h2o.varimp(rf4)


test = test[,x]
#test = test[,c(1:8,10:17)]
test1 = as.h2o(test)
pred =as.data.frame(h2o.predict(rf4, test1))

test2 = read.csv("5dc97593aef65_Testing_Dataset_final.csv")
test2$Winner = ifelse(pred$Red > 0.531, "Red", "Blue")
table(test2$Winner)
write.csv(test2 , row.names = F , "prediction.csv")

